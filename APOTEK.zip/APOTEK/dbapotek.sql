-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2020 at 05:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbapotek`
--

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `idpengguna` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `hakakses` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`idpengguna`, `username`, `password`, `hakakses`) VALUES
(1, 'doaibu', 'doaibu', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbdataobat`
--

CREATE TABLE `tbdataobat` (
  `idobat` varchar(25) NOT NULL,
  `nama_obat` varchar(30) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah_stok` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdataobat`
--

INSERT INTO `tbdataobat` (`idobat`, `nama_obat`, `satuan`, `harga`, `jumlah_stok`) VALUES
('AMX', 'Amoxilin', 'Tersedia', 3500, 91),
('CLX', 'Chloromax', 'Tersedia', 5000, 120),
('CTM', 'CTM', 'Tersedia', 2500, 90),
('CTP', 'Catopril', 'Tersedia', 45000, 92),
('FRM', 'Farmadol', 'Tersedia', 8000, 98),
('GBC', 'Glibenclamide', 'Tersedia', 7000, 115),
('MKN', 'Mikronazole', 'Tersedia', 1000, 90),
('ORL', 'Oralit', 'Tersedia', 18000, 897),
('PRC', 'Paracetamol', 'Tersedia', 2500, 53),
('SLB', 'Salbutamol', 'Tersedia', 4500, 44);

-- --------------------------------------------------------

--
-- Table structure for table `t_jual`
--

CREATE TABLE `t_jual` (
  `jual_nofa` bigint(20) NOT NULL,
  `jual_tgl` date NOT NULL,
  `jual_total` int(11) NOT NULL,
  `jual_cash` int(11) NOT NULL,
  `jual_kembali` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_jual`
--

INSERT INTO `t_jual` (`jual_nofa`, `jual_tgl`, `jual_total`, `jual_cash`, `jual_kembali`) VALUES
(20123000001, '2020-12-30', 18000, 20000, 2000),
(20123000002, '2020-12-30', 7000, 10000, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `t_jualdetail`
--

CREATE TABLE `t_jualdetail` (
  `jual_nofa` bigint(20) NOT NULL,
  `jual_barangid` varchar(30) NOT NULL,
  `jual_harga` int(11) NOT NULL,
  `jual_qty` int(11) NOT NULL,
  `jual_subtotal` int(11) NOT NULL,
  `jual_time` varchar(50) NOT NULL,
  `nama_pembeli` varchar(30) NOT NULL,
  `namabarang` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_jualdetail`
--

INSERT INTO `t_jualdetail` (`jual_nofa`, `jual_barangid`, `jual_harga`, `jual_qty`, `jual_subtotal`, `jual_time`, `nama_pembeli`, `namabarang`) VALUES
(20123000001, 'ORL', 18000, 1, 18000, '2020-12-30 10:35:14', '', 'Oralit'),
(20123000002, 'AMX', 3500, 2, 7000, '2020-12-30 10:56:09', 'pia', 'Amoxilin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
